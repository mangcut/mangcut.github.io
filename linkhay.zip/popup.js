(function(global){
	var handleButton = function(id){
		var btn = document.getElementById(id);
		btn.addEventListener('click', function() {
			chrome.runtime.sendMessage({cmdID: id}, function(response) {
				this.close();
			});
		});
	}
	
	document.addEventListener('DOMContentLoaded', function () {
		//handleButton("loadExternalUrl");
	});
})(this);
